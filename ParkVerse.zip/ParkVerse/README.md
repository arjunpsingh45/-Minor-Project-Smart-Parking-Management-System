# ParkVerse — Smart Parking Management System

## Run it
```
pip install -r requirements.txt
python app.py
```
Visit `http://127.0.0.1:5000`

## Pages
- `/` — landing page
- `/login` — user login
- `/signup` — user signup (name, email, 10-digit mobile, car number, vehicle class, password)
- `/booking` — booking dashboard (place, date/time, duration & live price, near-elevator preference, SVG floor plan, notifications bell, my bookings)
- `/admin-login` — admin login
- `/admin` — admin console (manage slots, view/cancel any booking, view registered users, revenue)

Each user-facing template is fully self-contained: CSS in a `<style>` block and JS in a `<script>` block in the same file — no separate `.css`/`.js` files.

## Demo admin account
```
email:    admin@parkverse.com
password: admin123
```
Seeded automatically on first run. **Change this before deploying anywhere real.**

## What's implemented
- **Pricing & duration** — every booking has an hourly rate (₹20/hr, see `RATE_PER_HOUR` in `app.py`), a duration field (1–24h) and an auto-calculated end time and price, shown live in the booking form and stored per booking.
- **Admin console** — a separate `is_admin` account type can log in at `/admin-login` to add/remove parking slots, toggle a slot's "near elevator" flag, cancel any user's booking, and view all registered users plus live revenue from active bookings.
- **Mock email/SMS confirmations** — there's no real email/SMS provider wired up (that needs a paid account with someone like SendGrid or Twilio), so `notify()` in `app.py` logs a confirmation to the server console and stores it in a `Notification` table. The booking page's bell icon shows this trail to the user so the flow is demonstrable end-to-end.
- **CSRF protection** — Flask-WTF issues a token via `/api/csrf-token`; every page fetches it on load and sends it back as `X-CSRFToken` on POST requests. Requests without a valid token are rejected with 400.
- **Rate limiting** — Flask-Limiter caps `/api/login`, `/api/signup` and `/api/admin-login` to a handful of attempts per minute per IP, to slow down brute-force attempts.
- **SVG floor plan** — the booking page no longer shows a flat grid; slots are drawn in an SVG floor plan around a central lift icon, with elevator-flagged slots automatically placed closest to it. Booked slots are visually distinct and unclickable.

## Database
SQLite, auto-created on first run as `parking.db`. Tables:
- `User` — includes `is_admin`
- `ParkingSlot` — 20 seeded slots, half flagged `near_elevator`
- `Booking` — place, time, duration, price, end time, elevator preference, status
- `Notification` — mock email/SMS confirmation trail per user

Passwords are hashed with Werkzeug's `generate_password_hash` — never stored in plain text.

## Still worth adding later
- A real email/SMS provider behind `notify()` (SendGrid/Twilio) instead of the console-log mock
- A persistent rate-limit storage backend (Redis) instead of in-memory, for multi-process deployments
- Auto-release of a slot once its `end_time` passes (currently bookings stay "Active" until manually cancelled)
- Role-based admin accounts (multiple operators) instead of one shared admin login
